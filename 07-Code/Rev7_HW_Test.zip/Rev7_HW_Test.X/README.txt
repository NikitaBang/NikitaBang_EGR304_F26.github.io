Rev7_HW_Test - hardware verification test for the Fill-A-Bot main control board (Rev 7)
PIC18F57Q43 Curiosity Nano, MPLAB X + XC8. One source file: main.c

OPEN IT
1. Unzip anywhere (Desktop is fine). You get this folder, Rev7_HW_Test.X
2. MPLAB X: File > Open Project > pick Rev7_HW_Test.X > Open Project
   Then right-click Rev7_HW_Test in the Projects pane > Set as Main Project.
   Its name should be in bold. (If another project is bold, THAT one gets programmed.)
   Easiest: close every other project first (right-click > Close).
3. If MPLAB says a compiler, pack or tool is missing:
   right-click Rev7_HW_Test in the Projects pane > Properties
     - Connected Hardware Tool: your Curiosity Nano (shows with a serial number once USB is in)
     - Packs: PIC18F-Q_DFP (any version you have)
     - Compiler Toolchain: XC8 (any version you have)
   Click OK.

PROGRAM IT
4. Barrel-jack adapter into J4 FIRST, then USB into the Nano.
   VOFF is tied to ground on this board, so USB alone does not power the PIC.
5. Click "Make and Program Device Main Project" (arrow pointing down into a chip).
   The Output window should end with "Programming complete".
   Check the build lines in Output say Rev7_HW_Test, not some other project.
   If the toolbar's "Hold in Reset" button is pressed in, click it to release.

SIGN OF LIFE
- The Nano's own little LED blinks about twice a second = the code is running.
- Not blinking = the PIC is not running this code. Check the main project and Hold in Reset.

WHAT IT DOES (all at once)
- Ribbon outputs RD4, RD3, RF6, RF5 (J2 pins 1-2, J3 pins 1-2): high 2 s, low 2 s, forever.
  About 4.4 V high with the 1N4007 diodes.
- Ribbon inputs: 5 V on J1 pin 3 -> D2 yellow, J1 pin 4 -> D3 green,
  J3 pin 3 -> D4 red. J3 pin 4 shows up in the Watch window only (ribbon_in bit 0).
- Cup sensor: RA5 read every 10 ms. Hold any button and the 3 LEDs become a level bar.

WATCH THE NUMBERS
6. Debug > Debug Main Project
7. Window > Debugging > Watches. Add: adc_value, adc_mv, ribbon_in, ribbon_out
8. Click Pause to refresh the values, Continue to run again.
9. When done: stop debugging (red square), then Make and Program once more.

CANVAS ZIP
10. Right-click the project > Package. The Output window says where the zip went.
